from attacks.delete_sys_log.main import DeleteSysLog
from attacks.file_permissions.main import FilePermission
import argparse


attacks = {
    "file_permission": FilePermission,
    "delete_sys_log": DeleteSysLog,
}


def main():
    parser = argparse.ArgumentParser(description="Run a command.")
    parser.add_argument("--attack", metavar="attack", type=str, nargs="+", help="The attacks to run")

    args = parser.parse_args()

    if not args.attack:
        print("no args")
        for attack_name, attack in attacks.items():
            print("processing ", attack_name)
            attack().execute()
    else:
        print("has args")
        for arg in args.attack:
            attack = attacks.get(arg)
            if not attack:
                print(f"attack {arg} not found")
            else:
                attack().execute()


if __name__ == "__main__":
    main()
