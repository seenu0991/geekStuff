class Attack:
    def check_dependencies(self):
        pass

    def get_dependencies(self):
        pass

    def attack(self):
        pass

    def clean_up(self):
        pass

    def execute(self):
        if not self.check_dependencies():
            self.get_dependencies()

        self.attack()
        self.clean_up()
