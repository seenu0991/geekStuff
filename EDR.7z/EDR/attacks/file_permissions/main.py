from attacks.attack import Attack


import subprocess


class FilePermission(Attack):
    def attack(self):
        numeric_mode = 644
        file_or_folder = "./fake_file.test"
        command = f"chmod {numeric_mode} {file_or_folder}"
        result = subprocess.run(command, shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            print("Command executed successfully.")
            print("Output:")
            print(result.stdout)
        else:
            print("Error executing the command.")
            print("Error message:")
            print(result.stderr)

        return super().attack()
